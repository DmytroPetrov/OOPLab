package sample;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {
    private Stage primaryStage;
    private BorderPane rootLayout;

    private ObservableList<Persons> personData = FXCollections.observableArrayList();

    public Main(){
        // Add some sample data
        personData.add(new Persons("Hans", "Muster"));
        personData.add(new Persons("Ruth", "Mueller"));
        personData.add(new Persons("Heinz", "Kurz"));
        personData.add(new Persons("Cornelia", "Meier"));
        personData.add(new Persons("Werner", "Meyer"));
        personData.add(new Persons("Lydia", "Kunz"));
        personData.add(new Persons("Anna", "Best"));
        personData.add(new Persons("Stefan", "Meier"));
        personData.add(new Persons("Martin", "Mueller"));
    }

    /**
     * Returns the data as an observable list of Persons.
     * @return
     */
    public ObservableList<Persons> getPersonData() {
        return personData;
    }

    @Override
    public void start(Stage primaryStage) throws Exception{
//        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
//        primaryStage.setTitle("Personal Information");
//        primaryStage.setScene(new Scene(root, 720, 620));

        /*Controller controller = root.getController;
        controller.setMainApp(this);
*/

        // Load person overview.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("sample.fxml"));
        AnchorPane personOverview = (AnchorPane) loader.load();

        // Give the controller access to the main app.
        Controller controller = loader.getController();
        controller.setMain(this);


        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
